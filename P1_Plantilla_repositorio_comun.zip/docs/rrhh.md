# Departamento de Recursos humanos

Responsable: PENDIENTE (nombre y usuario de GitHub)

# RA1 · El servidor

## 1. Su sitio en Apache
PENDIENTE: VirtualHost, portada y comprobación con curl.

## 2. Base de datos y PHP
PENDIENTE: sql/rrhh.sql, salida de SHOW GRANTS y de curl de estado.php.

## 3. Seguridad
PENDIENTE: HTTPS y redirección, zona privada, cortafuegos y SFTP, con la salida de cada comprobación.

## 4. Docker
PENDIENTE: docker/rrhh/, salida de docker compose ps y de curl.

## 5. Montar este sitio desde cero
PENDIENTE: los pasos en orden, con sus comandos y cómo se comprueba cada uno.

# RA2 · Gestores de contenidos

## 6. Gestor de contenidos
PENDIENTE: qué tipo de gestor usaría Recursos humanos, por qué y con qué licencia; WordPress en tu VM; captura de tu página (docs/img/rrhh-pagina.png).

## 7. Seguridad y pruebas
PENDIENTE: tu cuenta de editor, verify-checksums, tu página en la wiki y la tabla de pruebas.

# RA3 a RA7

Los apartados de cada RA se añaden al empezar su unidad, con el manual del sprint.
